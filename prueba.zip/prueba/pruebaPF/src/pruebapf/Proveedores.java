package pruebapf;
public class Proveedores 
{
    private String Direccion;
    private String nombre;
    private String RFC;
    public Pedido m_Pedido;


    public Proveedores()
    {

    }

    public void finalize() throws Throwable 
    {

    }
}
