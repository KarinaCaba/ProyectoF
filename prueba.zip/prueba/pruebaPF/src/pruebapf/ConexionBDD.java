package pruebapf;
public class ConexionBDD 
{
    private ConexionBDD ConexionBDD;

	public ConexionBDD(){

	}

	public void finalize() throws Throwable {

	}
	public ConexionBDD Instance(){
		return null;
	}
}
