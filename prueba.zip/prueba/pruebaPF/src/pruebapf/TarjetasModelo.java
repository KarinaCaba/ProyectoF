package pruebapf;

public class TarjetasModelo 
{
    private Tarjetas[] listaTarjetas;

    public TarjetasModelo()
    {

    }

    public void finalize() throws Throwable 
    {

    }
	
    public void altaTarjetaModelo(String nombre, Componentes[] piezas)
    {

    }

    public void cambiarEstatusModelo(String estatus)
    {

    }
}//end TarjetasModelo