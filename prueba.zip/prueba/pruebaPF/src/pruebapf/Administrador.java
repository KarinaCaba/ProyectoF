package pruebapf;
public class Administrador extends Persona 
{
    public Administrador()
    {
        
    }
}//end Administrador