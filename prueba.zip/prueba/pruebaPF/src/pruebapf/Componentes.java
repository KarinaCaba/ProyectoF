package pruebapf;
public class Componentes 
{
    private int cantidad;
    private int cvePieza;
    private String especificacion;
    private String nombre;

    public Componentes()
    {

    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getCvePieza() {
        return cvePieza;
    }

    public void setCvePieza(int cvePieza) {
        this.cvePieza = cvePieza;
    }

    public String getEspecificacion() {
        return especificacion;
    }

    public void setEspecificacion(String especificacion) {
        this.especificacion = especificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
       
	
}
