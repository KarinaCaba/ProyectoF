package pruebapf;

import java.time.LocalDate;

public class InventarioControlador 
{
    private InventarioModelo InventarioModelo;
    public InventarioModelo m_InventarioModelo;

    public InventarioControlador()
    {

    }

    public void finalize() throws Throwable 
    {

    }
	
    public void agregarPieza(String Modelo, int cantidad, Componentes Tipo)
    {

    }

    public void AgregarTarjeta()
    {

    }
    public void AltaPieza(Componentes tipo, String Modelo)
    {

    }
	
    public void AltaTarjeta()
    {

    }
	
    public void CambiarEstatusTrjeta(String statusNuevo)
    {

    }
	
    public void QuitarPieza(String Modelo, int cantidad, Componentes Tipo)
    {

    }
	
    public void RealizarPedido(Componentes Piezas, LocalDate FechaEntrega, int cantidad)
    {

    }
}
