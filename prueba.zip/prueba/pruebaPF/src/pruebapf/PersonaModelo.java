package pruebapf;

import java.time.LocalDateTime;

public class PersonaModelo 
{
    private Persona[ ] ListadoPersonas;
    public Persona m_Persona;
    public ConexionBDD m_ConeccionBDD;
    public Trabajador m_Trabajador;
    public Maquilador m_Maquilador;
    public PersonaModelo()
    {

    }
	
    public void finalize() throws Throwable 
    {

    }
	
    public int AltaTrabajador(String ApellidoM, String ApellidoP, String Nombre, String Direccion, String puesto)
    {
		return 0;
    }
	
    public boolean BajaTrabajador(int NumTrabajador)
    {
	return false;
    }
	
    public boolean ChecarEntrada(LocalDateTime horaEntrada)
    {
	return false;
    }
	
    public boolean ChecarSalida(LocalDateTime horaSalida)
    {
	return false;
    }
	
    public boolean ModificarTrabajador()
    {
	return false;
    }
}
