package pruebapf;

import java.time.LocalDate;

public class ReportesControlador 
{
    private LocalDate FechaEntrega;
    private LocalDate FechaFinReporte;
    private LocalDate FechaInicioReporte;
    private LocalDate FechaSolicitud;
    private int FolioReporte;
    private int PiezasTotales;

    public ReportesControlador()
    {

    }

    public void finalize() throws Throwable 
    {

    }
    public boolean CrearReporte()
    {
    	return false;
    }
    public boolean EnviarReporte()
    {
	return false;
    }
}
