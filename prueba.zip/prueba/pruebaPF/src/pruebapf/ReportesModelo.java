package pruebapf;

import java.time.LocalDate;

public class ReportesModelo 
{
    private Reportes[ ] ListadoReportes;
    public ReportesControlador m_ReportesControlador;
    public ConexionBDD m_ConeccionBDD;

    public ReportesModelo()
    {

    }

    public void finalize() throws Throwable 
    {

    }
	
    public void CrearReporte(LocalDate FechaEntrega, LocalDate FechaSolicitud, String TipoReporte, LocalDate FechaInicio, LocalDate FechaFin)
    {

    }

    public void EnviarReporte(char destinatario)
    {

    }
}
