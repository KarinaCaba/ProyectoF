package pruebapf;
public class PersonaControlador 
{
    public PersonaModelo m_PersonaModelo;
	
    public PersonaControlador()
    {

    }
	
    public void finalize() throws Throwable 
    {

    }
	
    public boolean AltaTrabajador()
    {
	return false;
    }
	
    public boolean AsignarPermisos()
    {
	return false;
    }
	
    public boolean BajaTrabajador()
    {
        return false;
    }
	
    public boolean ChecarEntrada()
    {
	return false;
    }
	
    public boolean ChecarSalida()
    {
	return false;
    }
	
    public boolean ModificarTrabajador()
    {
	return false;
    }
    
}
