package pruebapf;
public class InventarioModelo 
{
    private Inventario inventario;
    public ConexionBDD m_ConeccionBDD;
    public Componentes m_Componentes;
    public Tarjetas m_Tarjetas;
    public Pedido m_Pedido;

    public InventarioModelo()
    {

    }

    public void finalize() throws Throwable 
    {

    }
	
    public void AgregarPieza()
    {

    }
    
    public void AgregarTarjeta()
    {

    }
	
    public void AltaPieza()
    {

    }
	
    public void AltaTarjeta()
    {

    }
	
    public void QuitarPieza()
    {

    }
	
    public void RealizarPedido()
    {

    }
	
}
