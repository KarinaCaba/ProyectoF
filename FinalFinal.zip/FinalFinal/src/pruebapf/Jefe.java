package pruebapf;
public class Jefe extends Persona
{
    private String correo;
    private String telefono;

    public Jefe()
    {

    }

    public void finalize() throws Throwable 
    {
	super.finalize();
    }
}
