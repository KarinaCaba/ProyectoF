package pruebapf;
public class TarjetasControlador 
{
    public TarjetasControlador()
    {

    }

    public void finalize() throws Throwable 
    {
        
    }
    public void altaTarjetaControlador()
    {

    }
}
