package pruebapf;

public class PruebaPF 
{
    public static void main(String[] args) 
    {
        ventanaPrincipal v1 = new ventanaPrincipal();
    }
}